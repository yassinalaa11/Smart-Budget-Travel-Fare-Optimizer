"""SmartFare data ingestion package."""
