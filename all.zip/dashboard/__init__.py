"""SmartFare Streamlit dashboard."""
