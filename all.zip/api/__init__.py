"""SmartFare HTTP API."""
